const CONFIG = [
    {
        context: [ '/**' ],
        traget: 'http://localhost:8080',
        secure: false,
        logLevel: "debug"
    } 
];

module.exports = CONFIG;