import { Component } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  search: boolean = true;

  searchGIFY(){    
        this.search = true
        console.log("Search GIFY Clicked")
      }

      savedGIFY(){    
        this.search = false
        console.log("Saved GIFY Clicked")
      }

      ngOnInit() {     
      }
}
