import { Component, OnInit } from '@angular/core';
import { ImageService } from '../shared/image.service';
import { error } from 'util';

@Component({
  selector: 'app-image-result',
  templateUrl: './image-result.component.html',
  styleUrls: ['./image-result.component.css']
})
export class ImageResultComponent implements OnInit {

  images: any[] = [];

  constructor(private _imageService : ImageService) { }

  ngOnInit() {
    this._imageService.getAllGify()
      .then(result => {
        this.images = result;
        console.log("Result", result);
      })
      .catch(error => {
        console.log("Error", error);
      })
  }
}
