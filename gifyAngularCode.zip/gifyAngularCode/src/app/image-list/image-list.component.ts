import { Component, OnInit, transition } from '@angular/core';
import { ImageService } from '../shared/image.service';
import { Subscriber } from 'rxjs/Subscriber';
import { ngControlStatusHost } from '@angular/forms/src/directives/ng_control_status';

@Component({
  selector: 'app-image-list',
  templateUrl: './image-list.component.html',
  styleUrls: ['./image-list.component.css']
})
export class ImageListComponent implements OnInit {

  title = 'GIPHY Search';

  images: any[];
  imagesFound: boolean = false;
  searching: boolean = false;

  handleSuccess(data){
    this.imagesFound=true;
    this.images=data.data;
      console.log(data.hits);
  }

  handleError(error){
    console.log(error);
  }

  constructor(private _imageService : ImageService) { }

  searchImages(query: string, limit: string){

    this.searching = true //Loading Stauts

    //promise call to service
    return this._imageService.getImage(query,limit).subscribe(
      //returned key/value form API
      data => this.handleSuccess(data),
      error => this.handleError(error),
      () => this.searching = false
    )
  }

  ngOnInit() {     
  }

}
