import {Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import {Http, Headers} from '@angular/http';
import { HttpClient } from '@angular/common/http';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/take';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class ImageService{
    private query: string;

    //get API data from Environment
    private API_KEY: string = environment.API_KEY;
    private API_URL: string = environment.API_URL;

    //API_URL = https://api.giphy.com/v1/gifs/search?api_key=
    //API_KEY = nvsLH5CxiOx2M6DeepifAIgGYOwyOEXn
    //https://api.giphy.com/v1/gifs/search?api_key=nvsLH5CxiOx2M6DeepifAIgGYOwyOEXn&q=SERACHKEYWORD&limit=NumberOfPicture
    private URL: string = this.API_URL + this.API_KEY + '&q=';

    constructor(private _http: Http, private http: HttpClient){}

    getAllGify(): Promise<any>{
        return (this.http.get('http://localhost:8080/gifySearch_server/savegify')
                .take(1)
                .toPromise());
    }

    getImage(query, limit){
        //url call to GIPHY website with search keyword and limit
        return this._http.get(this.URL + query+"&limit="+limit).map(res => res.json());
    }
}